﻿namespace SD.Toolkits.WebApi.Tests.Models
{
    public enum Gender
    {
        Male = 0,

        Female = 1
    }
}
