﻿using Microsoft.Owin;
using SD.Toolkits.WebApi.Tests;

// OWIN启动器
[assembly: OwinStartup(typeof(Startup))]
